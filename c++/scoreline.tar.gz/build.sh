g++ -std=c++11 -pthread -O2 -o score_line simulate_progression.cpp main.cpp random.cpp rdtsc.cpp
